# HireMe Evidence Rubric

Use this reference when building the shared job-to-resume evidence matrix.

## Evidence grades

| Grade | Meaning | Permitted language |
|---|---|---|
| Explicit | Directly stated in the resume with role, duty, credential, population, system, or result. | State as documented evidence. |
| Strongly implied | Supported by multiple related facts but not stated verbatim. | Say “suggests” or “supports transferability”; do not convert into direct ownership. |
| Weakly implied | A plausible connection based on title or adjacent experience. | Present only as a hypothesis or interview clarification. |
| Absent | Not found in the supplied resume. | Call it an evidence gap; never invent it. |

## Scoring

Build a 100-point rubric tailored to the posting. Score each criterion according to documented evidence, not presumed capability. Use the following guide, then apply professional judgment:

- Full or near-full credit: requirement is explicit, recent or sustained, and closely aligned.
- Moderate credit: requirement is explicit but narrower, older, less senior, or transferable rather than direct.
- Limited credit: adjacent evidence exists, but material scope or context is absent.
- No credit: no defensible evidence is present.

Always explain the reason for a deduction. Distinguish a missing resume detail from a demonstrated weakness. Do not express the score as a probability of being hired.

## Matrix fields

For each material criterion, record:

| Field | Required content |
|---|---|
| Requirement | Concise normalized statement of the posting requirement. |
| Weight | Importance in the tailored 100-point model. |
| Resume evidence | Exact role, credential, duty, population, system, or result supporting the criterion. |
| Evidence grade | Explicit, strongly implied, weakly implied, or absent. |
| Transferability | What adjacent experience may credibly transfer, if any. |
| Gap or ambiguity | What the resume does not establish. |
| Score | Earned points and maximum points. |
| Interview implication | Strength to emphasize, proof to prepare, or safe process answer. |

## Safety rules

Never fabricate metrics, team sizes, budgets, dates, credentials, regulatory experience, union exposure, patient populations, outcomes, or ownership. Use `[confirm metric]` or `[insert accurate example]` when a detail would materially improve an answer but is not supplied. For legal, regulatory, clinical, or employment matters, describe preparation and decision process rather than giving individualized advice.

When writing a challenging-area answer, use this sequence: acknowledge the boundary of direct experience; state the transferable evidence; explain a sound process; identify when to consult HR, labour relations, clinical, legal, or other experts; and commit to documentation, confidentiality, and follow-through.
