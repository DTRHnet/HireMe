# Manus Execution Checklist

Use this as the implementation sequence after reading the master instructions.

## Phase 1 — Understand

- Read all files in `reference/hireme-skill/`.
- Inspect existing repository.
- Identify current framework and dependencies.
- Do not replace a working stack unnecessarily.

## Phase 2 — Foundation

- Establish application layout.
- Establish navigation.
- Add typed domain models.
- Add environment configuration.
- Add error/loading primitives.

## Phase 3 — Documents

- Implement paste inputs.
- Implement PDF/DOCX/TXT uploads.
- Implement extraction.
- Add provenance.
- Add extraction warnings.

## Phase 4 — Normalization

- Implement schemas.
- Implement deterministic normalization.
- Add validation.
- Add normalized-data inspector.

## Phase 5 — HireMe Engine

- Implement evidence matrix.
- Implement evidence grades.
- Implement tailored 100-point score.
- Implement deduction explanations.
- Implement hallucination safeguards.

## Phase 6 — LLM Layer

- Implement provider interface.
- Implement provider adapters.
- Implement staged prompts.
- Implement structured output validation.
- Implement retries.

## Phase 7 — Documents

- Implement Resume Fit Assessment.
- Implement Interview Study Guide.
- Implement consistency audit.

## Phase 8 — Export

- Markdown
- JSON
- CSV
- PDF
- DOCX where supported

## Phase 9 — Settings/History

- Provider settings
- Connection test
- Local history
- Privacy controls
- Skill download

## Phase 10 — Polish

- Responsive UI
- Accessibility
- Empty states
- Error states
- Loading states
- Tables
- Long-document rendering

## Phase 11 — Verify

Run the complete acceptance checklist in `09-TESTING-AND-ACCEPTANCE.md`.

Then inspect the final product manually at desktop and mobile widths.

Do not declare completion until the end-to-end workflow works.
