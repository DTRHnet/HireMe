# Settings, History and Privacy

## Settings

Create a Settings screen with:

### Provider
- OpenAI
- Anthropic
- Google Gemini
- OpenRouter
- Ollama
- LM Studio
- OpenAI-compatible

### Connection
- endpoint
- API key
- model
- connection test

### Generation
- temperature
- max tokens
- streaming

### Privacy
- local-only preference where possible
- save history toggle
- clear all local data

Show whether the selected provider is local or remote.

## Secrets

Never persist plaintext API keys on a server.
Prefer browser-local storage only when appropriate and explain the risk. Better architecture: keep secrets server-side when the application has an authenticated backend, or use secure environment/user secret storage.

## History

History is local-first.
Allow:
- create
- reopen
- rename
- delete
- clear all

Do not silently upload resumes or history.
