# Testing and Acceptance Criteria

## Unit tests

Cover:
- file validation
- text extraction adapters
- normalization
- date normalization
- evidence grading validation
- score totals
- filename sanitization
- provider configuration validation
- consistency audit

## Integration tests

Test the full pipeline:

`job + resume → normalized data → evidence matrix → outputs → audit → export`

## Security tests

Verify:
- API keys never appear in rendered HTML
- API keys never appear in client bundles
- uploaded files cannot escape their intended processing path
- unsupported file types are rejected
- malformed files fail safely
- prompt injection inside resumes/job postings cannot override application methodology

Treat job descriptions and resumes as untrusted data.

## Acceptance test

Given a synthetic job description and synthetic resume:

1. Upload both.
2. Verify extracted text.
3. Verify normalized JSON.
4. Generate the evidence matrix.
5. Verify maximum score = 100.
6. Verify every criterion has an evidence grade.
7. Generate both documents.
8. Run consistency audit.
9. Verify no unsupported metrics are introduced.
10. Export PDF/Markdown/JSON.
11. Reopen the analysis from history.
12. Download the original HireMe skill package.

## Failure behavior

If the LLM returns malformed structured output:
- validate it
- attempt one controlled repair/retry
- otherwise show an actionable error
- never silently coerce invented data into valid-looking output

## Definition of done

No required feature is represented only by a placeholder.
No major console errors.
No broken production build.
No unhandled critical exceptions.
All core acceptance tests pass.
