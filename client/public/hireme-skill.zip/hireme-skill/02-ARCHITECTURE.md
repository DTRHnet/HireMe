# Architecture Specification

Use a modular TypeScript architecture. If Manus selects a different framework, preserve these boundaries.

Suggested stack:
- Next.js
- React
- TypeScript
- Tailwind CSS
- shadcn/ui
- Zod
- local persistence via IndexedDB/localStorage where appropriate
- server-side API routes for provider calls

Suggested domains:

`src/features/analysis`
`src/features/documents`
`src/features/evidence`
`src/features/llm`
`src/features/exports`
`src/features/history`
`src/features/settings`

Suggested analysis pipeline:

`RawInput → ExtractedDocument → NormalizedDocument → EvidenceMatrix → AnalysisOutputs → Audit → Export`

Each stage must have explicit typed input/output schemas.

Do not couple UI components directly to provider SDKs.

Create:

`LLMProvider`

with methods conceptually equivalent to:
- validateConfiguration
- generateStructured
- generateText
- streamText when supported

Provider implementations should be replaceable.

Keep methodology-specific logic separate from transport/UI code so HireMe can later become one skill among many.
