# HireMe Web App — Master Manus Build Instructions

## Mission

Build a polished, production-quality web application named **HireMe** that operationalizes the supplied HireMe skill package.

The application accepts exactly two primary analysis inputs:

1. Job description
2. Candidate resume

It extracts and normalizes both inputs, builds a shared evidence matrix, runs the HireMe analysis through a user-configurable LLM, generates a Resume Fit Assessment and an Interview Study Guide, and lets the user inspect and download the underlying artifacts.

## Authoritative reference

Before implementing analysis behavior, read every file under:

`reference/hireme-skill/`

including `SKILL.md` and every file under `references/`.

The supplied skill is the authoritative methodology. The web app is an interface and execution layer around it.

Do not replace the methodology with a generic "resume scorer".

## Manus execution behavior

Work as an autonomous senior product engineer.

- Inspect the repository before changing it.
- Create a written implementation plan before major code changes.
- Implement in coherent phases.
- Keep the application runnable after each phase.
- Prefer real functionality over mock UI.
- Do not leave placeholder buttons for required features.
- If a dependency or API is unavailable, implement a clean adapter/fallback rather than hardcoding a fake success state.
- Validate all external data with typed schemas.
- Never expose API keys to the browser or client bundle when a server-side route is available.
- Never send resume/job data to a remote provider without clear user action and a visible privacy indication.

## Required application capabilities

### Inputs
- Paste job description
- Upload job description: PDF, DOCX, TXT
- Paste resume
- Upload resume: PDF, DOCX, TXT
- Drag and drop
- Extract text with source provenance
- Show extraction warnings

### Processing
1. Input validation
2. Document extraction
3. Canonical normalization
4. Requirement parsing
5. Resume evidence inventory
6. Shared evidence matrix
7. Tailored 100-point documented-fit heuristic
8. Resume Fit Assessment
9. Interview Study Guide
10. Cross-document consistency audit
11. Export

### LLM
Support an adapter architecture for:
- OpenAI
- Anthropic
- Google Gemini
- OpenRouter
- Ollama
- LM Studio
- Generic OpenAI-compatible endpoint

Provider/model must be selectable in Settings.

### Outputs
- Resume Fit Assessment
- Interview Study Guide
- Evidence Matrix
- Normalized Job JSON
- Normalized Resume JSON
- Full analysis JSON
- Markdown
- PDF
- DOCX where practical
- CSV export for the evidence matrix

### Skill download
Provide a **Download HireMe Skill** action that downloads the supplied original skill archive/package unchanged.

## Non-negotiable methodology rules

- Source documents are the source of truth.
- Never invent credentials, dates, metrics, achievements, team sizes, budgets, duties, populations, systems, legal experience, union exposure, or outcomes.
- Distinguish explicit evidence from inference.
- Evidence grades are Explicit, Strongly implied, Weakly implied, or Absent.
- Missing information is an evidence gap, not permission to hallucinate.
- Scores describe documented fit, not probability of hiring.
- Explain deductions.
- Both deliverables must derive from the same evidence matrix.
- Run a consistency audit before export.
- Protect confidential information.

## Product quality bar

The finished application should feel like a serious professional SaaS product rather than a demo.

It must have:
- responsive design
- accessible controls
- clear loading/progress states
- useful empty states
- robust error handling
- retry behavior
- readable long-form results
- mobile usability
- keyboard accessibility
- no layout-breaking tables
- no fake metrics
- no silent failures

## Required final validation

Before declaring the project complete:

1. Run type checking.
2. Run linting.
3. Run unit/integration tests.
4. Build the production application.
5. Exercise the complete analysis flow using a synthetic job description and synthetic resume.
6. Test malformed files and empty inputs.
7. Test at least one local LLM provider and one remote/provider adapter when credentials are available.
8. Verify API keys are not leaked to client-side output.
9. Verify exports open successfully.
10. Verify the skill download is the supplied package and has not been modified.
11. Fix all high-severity issues before completion.

Use the remaining prompt files as detailed specifications.
