---
name: hireme
description: Create a formal Resume Fit Assessment and a practical Interview Study Guide from a job description and personal resume. Use when a user wants role-fit analysis, interview preparation, or polished candidate documents based on supplied job-post and resume files.
---

# HireMe

Transform a supplied **job description** and **personal resume** into two consistent, evidence-grounded deliverables: a formal **Resume Fit Assessment** and a practical **Interview Study Guide**. Read the relevant references in `references/` before drafting.

## Operating principles

Use the supplied files as the source of truth. Separate what the resume explicitly proves from what it merely suggests and from what is absent. Never invent credentials, dates, metrics, team sizes, budgets, duties, patient/client populations, systems, legal experience, union exposure, or outcomes. If a useful detail is missing, write `[confirm metric]` or `[insert accurate example]`, or describe a process that does not require claiming direct experience.

Treat the numerical score as a transparent heuristic for **documented fit**, not as a hiring probability or diagnosis of the candidate’s actual ability. Explain deductions. Label evidence gaps as gaps in documentation unless the supplied material demonstrates a genuine weakness. Protect confidential personal, patient, client, and employer information.

## Workflow

1. **Inspect the inputs.** Accept PDF, DOCX, and text files where available. Extract headings, dates, roles, credentials, bullets, tables, and quantified results. Preserve the candidate name, target role, employer, and source dates. If extraction is incomplete or image-only, use OCR or ask for a clearer file rather than guessing.
2. **Parse the posting.** Identify mandatory and preferred qualifications, responsibilities, scope, operational expectations, leadership behaviors, legal or regulatory requirements, systems, and implied panel criteria. Preserve important distinctions such as practice versus management, adjacent versus direct domain experience, and performance management versus labour relations.
3. **Parse the resume.** Inventory education, registration, certifications, roles, dates, populations, leadership, operations, HR, change, quality, data, stakeholder work, and outcomes. Grade each item as explicit, strongly implied, weakly implied, or absent.
4. **Build one shared evidence matrix.** For every material criterion, record the normalized requirement, weight, exact resume evidence, evidence grade, transferability, gap or ambiguity, score, and interview implication. Use a tailored 100-point model; adapt categories to the role rather than copying a healthcare rubric mechanically. Read `references/evidence-rubric.md` for definitions and scoring safeguards.
5. **Draft the Resume Fit Assessment.** Follow `references/assessment-template.md`. Keep it formal, analytical, candid, and evidence-led. Include the total score, weighted rubric, criterion-by-criterion analysis, strengths, interview risks, positioning statement, recommendation, checklist, and source note.
6. **Draft the Interview Study Guide.** Follow `references/study-guide-template.md`. Derive every recommendation from the same matrix. Make it conversational and usable aloud, with an opening answer, motivation answer, keywords, review topics, adaptable STAR story bank, mock questions, challenging-area scripts, panel questions, schedule, checklist, closing statement, and source note.
7. **Run a consistency audit.** Confirm both files use the same candidate, role, employer, evidence, score total, and treatment of gaps. Confirm each number and achievement is sourced or marked for verification. Remove unsupported superlatives and confidential identifiers.
8. **Render and inspect.** Produce the requested editable or printable format. Read `references/formatting-spec.md` for visual requirements. Inspect the cover, contents, first table, dense body page, callout page, and final page. Fix table clipping, bad page breaks, orphan headings, missing headers or footers, font substitution, and unreadable spacing before delivery.

## Deliverable distinction

The **Resume Fit Assessment** is a decision-support report for diagnosing alignment and interview burden. It should sound like a careful evaluator comparing a posting with documented evidence.

The **Interview Study Guide** is a candidate-facing workbook for preparation and speaking practice. It should sound supportive but candid, emphasize natural speech, and turn evidence gaps into honest preparation or process answers.

Do not merge the two documents into one file unless the user explicitly asks. Use clear filenames based on candidate and role, such as `Candidate_Role_Resume_Fit_Assessment` and `Candidate_Role_Interview_Study_Guide`, with unsafe filename characters removed.

## Formatting defaults

Apply the same restrained professional identity to both files while preserving their different purposes. The assessment should use a formal report treatment: centered cover page, contents page with dotted leaders, blue numbered headings, generous margins, conservative document typography, blue table headers with dark rules, running title/brand header, centered page numbers, and distinct callouts for `Bottom line`, `Interview emphasis`, and `Safe interview formulation`.

The study guide should use a practical workbook treatment: bold headings, comfortable line spacing, lightly shaded two- and three-column tables, bordered or shaded script callouts, first-person answer text, and a rapid-review layout. Keep tables readable across page breaks and avoid orphaned headings. Follow `references/formatting-spec.md`; if the execution environment has no document renderer, preserve the semantic structure in Markdown and state the limitation rather than pretending visual fidelity.

## Clarification policy

Ask a focused question only when a missing input materially prevents accurate generation—for example, no resume, no job description, or an ambiguous target role when several roles are present. Otherwise proceed, state concise assumptions in the source note, and mark uncertain details for confirmation. Do not ask the user to supply information that can be safely handled as a labeled evidence gap.
