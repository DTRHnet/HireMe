# HireMe Formatting Specification

Use these specifications when generating editable or printable files. Treat the values as defaults and preserve the visual hierarchy even when the target format differs.

## Shared identity

Use a restrained professional palette: dark charcoal body text, a medium-to-dark blue accent for the formal assessment, white space, thin rules, and conservative typography. Use consistent candidate, role, employer, date, and assistant/brand metadata across both files. Prefer readable page density over forcing content onto fewer pages.

## Resume Fit Assessment

Use a centered cover page followed by a contents page. Use numbered section headings with blue accent styling and a running header on body pages containing the report title on the left and assistant/brand label on the right, separated by a thin rule. Center page numbers in the footer. Use blue-filled table header rows with dark borders and allow wrapped text in assessment cells. Add visually distinct callout blocks for `Bottom line`, `Interview emphasis`, and `Safe interview formulation`.

Keep the report formal and spacious. Avoid dense bullet walls. Use paragraphs for reasoning and tables for structured comparisons. Keep each major section heading with at least the first paragraph or table row on the same page. Do not allow table text to be clipped or reduced below comfortable reading size.

## Interview Study Guide

Use bold, prominent headings and comfortable line spacing. Use lightly shaded tables for mappings, mock questions, and panel questions. Use a left-rule or shaded blockquote treatment for opening, challenging-area, and closing scripts. Keep question-and-answer-focus tables concise enough to scan quickly. Use bold labels such as `Use for`, `Situation`, `Action`, `Result`, and `Lesson` to support oral practice.

Do not force a cover page if it creates unnecessary length; begin with a clear title and central-message callout. Use page numbers or a simple running title when supported. Maintain ample white space around tables and callouts, and prevent headings from being stranded at the bottom of a page.

## File and rendering rules

Use safe filenames with candidate and role identifiers. If fonts, brand assets, or exact pagination are unavailable, preserve the semantic hierarchy and disclose the limitation in the delivery note. Always inspect representative rendered pages for overflow, orphan headings, broken tables, missing metadata, and inconsistent page numbering before delivering.
