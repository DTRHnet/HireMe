# Product Requirements

## Core workflow

The primary screen is an Analyze workspace with two input cards:

### Job Description
- text editor
- upload button
- drag/drop
- file name/status
- extracted text preview
- clear/reset

### Resume
Same capabilities.

The primary CTA is:

**Generate HireMe Assessment**

Show a processing timeline:

`Extract → Normalize → Analyze Evidence → Score → Draft → Audit → Ready`

## Results

Use a results workspace with tabs:

- Overview
- Resume Fit Assessment
- Interview Study Guide
- Evidence Matrix
- Normalized Data
- Audit

The Overview should surface:
- documented-fit score
- strongest alignments
- largest evidence gaps
- major interview preparation areas
- selected provider/model

Do not present the score as a probability.

## Evidence Matrix

Provide sortable/filterable rows with:
- Requirement
- Category
- Weight
- Evidence
- Grade
- Transferability
- Gap
- Earned score
- Interview implication

Allow JSON/CSV export.

## History

Local-first history with:
- candidate
- role
- employer
- date
- score
- provider/model
- reopen/delete

History should be opt-in or clearly controlled in Settings.

## About

Explain the methodology briefly and include a link/button for downloading the original HireMe skill package.
