# LLM Orchestration

Do not use one uncontrolled prompt for the entire task.

Use a staged pipeline.

## Stage 1 — Validation

Input: normalized job + normalized resume.

Output: structured validation warnings.

Check for:
- missing target role
- missing employer
- extraction anomalies
- contradictory dates
- duplicate roles
- suspicious OCR
- empty sections

## Stage 2 — Evidence Matrix

Provide the normalized data and the relevant HireMe methodology/reference content.

Require strict structured JSON output matching the schema.

The model must cite source spans from the supplied normalized documents.

## Stage 3 — Resume Fit Assessment

Generate from the evidence matrix only.

Follow the supplied assessment template.

## Stage 4 — Interview Study Guide

Generate from the evidence matrix only.

Follow the supplied study-guide template.

## Stage 5 — Consistency Audit

Compare both generated artifacts against the matrix.

Check:
- candidate identity
- target role
- employer
- score
- evidence claims
- metrics
- credentials
- gaps
- recommendations

Return structured audit results and block export on critical unsupported claims.

## Provider settings

Settings must support:
- provider
- model
- endpoint/base URL where applicable
- API key
- temperature
- max tokens
- streaming

Prefer structured output / JSON schema when provider supports it.

For local providers, support Ollama and LM Studio through configurable endpoints.

Never expose secrets to client JavaScript.
