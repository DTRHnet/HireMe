# Evidence Engine

This module is the analytical core of the HireMe application.

Read and obey:
- `reference/hireme-skill/SKILL.md`
- `reference/hireme-skill/references/evidence-rubric.md`

## Evidence matrix

For every material job criterion produce:

```ts
{
  id: string,
  requirement: string,
  category: string,
  mandatory: boolean,
  weight: number,
  resumeEvidence: EvidenceReference[],
  evidenceGrade: "Explicit" | "Strongly implied" | "Weakly implied" | "Absent",
  transferability: string,
  gapOrAmbiguity: string | null,
  earnedScore: number,
  maximumScore: number,
  interviewImplication: string
}
```

The total maximum score must equal exactly 100.

Weights must be tailored to the target role.

Do not mechanically use a healthcare-specific rubric for unrelated roles.

## Scoring safeguards

The scoring engine must be auditable.

For every score, a user should be able to answer:
- What requirement was scored?
- What weight did it have?
- What resume evidence supports it?
- What evidence grade was assigned?
- Why was the earned score awarded?
- What information was missing?

No score may be based solely on semantic similarity.

Semantic matching may assist discovery, but the final evidence decision must be grounded in source text and the skill's evidence definitions.

## Hallucination prevention

Reject or flag generated claims when they introduce:
- unsupported numbers
- unsupported credentials
- unsupported dates
- unsupported job duties
- unsupported management scope
- unsupported clinical/legal/regulatory experience
- unsupported outcomes

When uncertain, explicitly label the gap.
