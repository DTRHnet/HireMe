# UI / UX Design Specification

Build a clean, premium professional interface.

Visual direction:
- restrained
- document/workflow oriented
- high readability
- strong typography
- subtle borders
- generous spacing
- minimal decorative noise

## Main navigation
- Analyze
- History
- Settings
- About

## Analyze page

Use a two-column layout on desktop and stacked cards on mobile.

Each input card should show:
- title
- paste area
- upload control
- drag/drop state
- extracted text preview
- extraction status
- clear action

## Processing

Use a visible stepper/progress panel.
Never imply an analysis is complete while a later validation stage is still running.

## Results

Use sticky result navigation or tabs.
Make long reports easy to scan.

Use badges for evidence grades.

The Evidence Matrix should support horizontal scrolling on narrow screens without breaking the entire page.

## Accessibility

- semantic headings
- keyboard navigation
- visible focus states
- sufficient contrast
- aria labels
- no color-only meaning
- readable font sizes

## Empty/error states

Every major component needs a useful empty state and actionable error message.
