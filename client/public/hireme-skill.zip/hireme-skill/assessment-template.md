# Resume Fit Assessment Template

Use this reference for the first deliverable. Keep the section order unless the role makes a small adaptation necessary.

## Front matter

Create a cover page with the title **Resume Fit Assessment**, the target role and employer, `Prepared for [Candidate]`, a one-line descriptor such as `Detailed role-fit analysis based on the supplied job description and resume`, and `Prepared by [assistant/brand] [date]`. Follow with a contents page using numbered sections and dotted leaders.

## Required sections

### 1 Executive assessment

State the overall score out of 100, the overall fit judgment, the strongest alignments, and the most important evidence gaps. Include a short callout labeled **Bottom line** that translates the assessment into the central interview burden.

### 2 Weighted scoring rubric

Use a table with `Area`, `Weight`, `Score`, and `Assessment`. Ensure the weights total 100 and the earned scores sum to the stated total. Keep each assessment concise but evidence-based.

### 3 Detailed fit analysis

Create one numbered subsection for every rubric area. Use a heading such as `3.1 1. [Criterion] — [earned]/[maximum]`. Explain the strongest evidence, the limits or ambiguity, and what the panel may test. End with a tactical label: **Interview emphasis**, **Clarification needed**, or **Safe interview formulation**.

### 4 Key strengths to emphasize

Use a compact table or numbered blocks. For each strength, state why it matters for this role and which resume evidence proves it.

### 5 Main interview risks and how to manage them

Frame each risk as a realistic panel question or concern, such as “You have adjacent experience, but have you owned this exact environment?” Explain the concern, identify the evidence boundary, and provide a defensible response strategy.

### 6 Interview-ready positioning statement

Write a natural first-person opening of approximately 60–90 seconds. Present the candidate as the combination of the most relevant domain expertise, leadership evidence, and motivation. Do not include unsupported superlatives.

### 7 Final recommendation

Give a calibrated recommendation such as strong fit, credible fit with clarification areas, or partial fit requiring substantial repositioning. Tie it to evidence and name the top actions that could change the outcome.

### 8 Immediate preparation checklist

Prioritize the gaps and stories most likely to affect the interview. Include specific evidence to confirm, examples to rehearse, concepts to review, and questions to prepare.

### 9 Method and source note

Name the supplied job description and resume as the sources. State that the score reflects visible evidence in those materials and that all examples, metrics, dates, and claims must be corrected to the candidate’s accurate history.

## Tone

Use formal, candid, analytical prose. Avoid generic praise, resume rewriting, unsupported hiring predictions, and claims that the score is objective. Prefer “the resume demonstrates,” “the posting requires,” and “the panel may probe.”
