# Interview Study Guide Template

Use this reference for the second deliverable. Derive all content from the shared evidence matrix and keep the tone practical, conversational, and usable aloud.

## Required sections

1. **Central message**: a short boxed statement summarizing the candidate’s most credible value proposition.
2. **What the panel is likely looking for**: translate posting language into decision criteria, operational priorities, and natural role vocabulary.
3. **Your strongest fit with the posting**: use `Requirement or responsibility`, `Evidence from your resume`, and `How to position it in the interview` columns.
4. **60–90 second opening answer**: write in first person and connect domain expertise, leadership, operations, quality, and motivation.
5. **Why this role and why this employer?**: organize around genuine motivation, relevant contribution, and informed fit; never invent employer facts.
6. **Keywords to use naturally**: provide themes and phrases that fit the posting and the candidate’s evidence without keyword stuffing.
7. **Topics to review before the interview**: identify unfamiliar laws, regulations, domain practices, systems, metrics, or operating concepts; distinguish review from claimed expertise.
8. **Adaptable STAR story bank**: for each story, give a title, `Use for` competencies, and prompts for Situation, Task, Action, Result, and Lesson. Use placeholders for unconfirmed metrics.
9. **Mock interview questions and answer focus**: use `Question` and `What the panel wants to hear` columns. Focus on answer ingredients rather than writing a long script for every question.
10. **Suggested answers to challenging areas**: provide short first-person answers for the largest evidence gaps. Acknowledge limits, state transferable experience, explain a sound process, and avoid overclaiming.
11. **Questions to ask the panel**: use `Question` and `Why it is useful` columns. Favor questions about priorities, success measures, team/service challenges, onboarding, decision rights, and culture.
12. **Same-day preparation schedule**: divide preparation into realistic time blocks, moving from opening answers to stories, technical review, vocabulary, logistics, and closing.
13. **Final rapid-review checklist**: summarize evidence discipline, role framing, preferred language, examples, confidentiality, and gaps to handle honestly.
14. **Closing statement and Source note**: write a concise first-person close and identify the supplied inputs. State that all metrics and examples require accuracy checks.

## Answer-design rules

Make answers speakable and specific. Connect each operational decision to safety, service quality, people support, reliability, stakeholder communication, and measurable improvement when supported by the posting. Use STAR structure for examples, but do not fabricate results. For sensitive topics, use process language: clarify facts and expectations, document objectively, follow policy or agreement, consult the appropriate expert, protect confidentiality, and follow through.

Use the candidate’s real roles as story anchors. Map one story to several plausible competencies, but do not reuse it mechanically when another example is stronger. Keep the guide a preparation aid: it should provide structure and prompts that help the candidate speak naturally rather than encouraging memorization of every word.
