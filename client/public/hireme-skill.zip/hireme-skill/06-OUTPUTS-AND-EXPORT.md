# Outputs and Export

## Resume Fit Assessment

Follow:
`reference/hireme-skill/references/assessment-template.md`

It should contain, as applicable:
- executive assessment
- documented-fit score
- weighted rubric
- criterion analysis
- strengths
- interview risks
- positioning statement
- recommendation
- preparation checklist
- source note

## Interview Study Guide

Follow:
`reference/hireme-skill/references/study-guide-template.md`

It should contain, as applicable:
- value proposition
- panel priorities
- strongest alignments
- 60–90 second introduction
- motivation answer
- keywords
- review topics
- STAR story bank
- mock questions
- challenging-area responses
- panel questions
- preparation schedule
- rapid-review checklist
- closing statement
- source note

## Formatting

Follow:
`reference/hireme-skill/references/formatting-spec.md`

Provide polished browser rendering first.

Export:
- Markdown
- PDF
- DOCX where implementation permits
- JSON

Evidence Matrix:
- CSV
- JSON

Use sanitized filenames:
`Candidate_Role_Resume_Fit_Assessment.*`
`Candidate_Role_Interview_Study_Guide.*`

Do not merge documents by default.
