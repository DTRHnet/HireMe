# Normalization Engine

Build a deterministic preprocessing layer before final LLM reasoning.

## Job normalized schema

```ts
{
  title: string | null,
  employer: string | null,
  department: string | null,
  location: string | null,
  employmentType: string | null,
  responsibilities: Requirement[],
  mandatoryRequirements: Requirement[],
  preferredRequirements: Requirement[],
  certifications: Requirement[],
  education: Requirement[],
  systems: Requirement[],
  regulations: Requirement[],
  leadershipExpectations: Requirement[],
  operationalExpectations: Requirement[],
  keywords: string[],
  rawText: string,
  sourceSpans: SourceSpan[]
}
```

## Resume normalized schema

```ts
{
  candidateName: string | null,
  contact: Contact | null,
  summary: string | null,
  education: EvidenceItem[],
  registrations: EvidenceItem[],
  certifications: EvidenceItem[],
  skills: EvidenceItem[],
  systems: EvidenceItem[],
  employmentHistory: Employment[],
  leadership: EvidenceItem[],
  operations: EvidenceItem[],
  qualityImprovement: EvidenceItem[],
  stakeholderExperience: EvidenceItem[],
  rawText: string,
  sourceSpans: SourceSpan[]
}
```

Every extracted fact should retain provenance such as source section, page, and source text where available.

Unknown values must be null/empty rather than guessed.

## Extraction

Support PDF, DOCX and TXT.

Detect image-only PDFs. If OCR is supported, use it; otherwise show a clear extraction warning and require confirmation rather than inventing text.

Normalize dates into machine-readable form while retaining original date text.

Do not alter the semantic meaning of the source.
